import urllib, dateutil, pylab, datetime
import numpy as np
import statsmodels.api as sm

def __init__(self,series_id):

    # download fred series from FRED and save information about the series
    series_url = "http://research.stlouisfed.org/fred2/data/"
    series_url = series_url + series_id + '.txt'
    # webs = urllib.request.urlopen(series_url)
    webs = urllib.urlopen(series_url)
    raw = [line.decode('utf-8') for line in webs]

    for k, val in enumerate(raw):
        if raw[k][0:5] == 'Title':
            self.title = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'Sou':
            self.source = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'Sea':
            self.season = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'Fre':
            self.freq = " ".join(x for x in raw[k].split()[1:])
            if self.freq[0:5] == 'Daily':
                self.t=365
            elif self.freq[0:6] == 'Weekly':
                self.t=52
            elif self.freq[0:7] == 'Monthly':
                self.t=12
            elif self.freq[0:9] == 'Quarterly':
                self.t=4
            elif self.freq[0:6] == 'Annual':
                self.t=1
        elif raw[k][0:3] == 'Uni':
            self.units    = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'Dat':
            self.daterange = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'Las':
            self.updated  = " ".join(x for x in raw[k].split()[1:])
        elif raw[k][0:3] == 'DAT':
            raw2 = list(raw[k+1:])
            break

    date=list(range(len(raw2)))
    data=list(range(len(raw2)))

    # Create data for FRED object. Replace missing values with NaN string
    for k,n in enumerate(raw2):
        date[k] = raw2[k].split()[0]
        if raw2[k].split()[1] != '.':
            data[k] = float(raw2[k].split()[1])
        else:
            data[k] = 'NaN'

    self.idCode    = series_id
    self.data  = np.array(data)
    self.dates = date
    self.datenumbers = [dateutil.parser.parse(s) for s in self.dates]

def pc(self,log=True,method='backward',annualized=False):

    '''Transforms data into percent change'''

    T = len(self.data)
    t = self.t
    if log==True:
        pct = 100*np.log(self.data[1:]/self.data[0:-1])
    else:
        pct = 100*(self.data[1:]/self.data[0:-1] - 1)
    if annualized==True:
        pct = [t*x for x in pct]
    if method=='backward':
        dte = self.dates[1:]
    elif method=='forward':
        dte = self.dates[:-1]
    self.data  =pct
    self.dates =dte
    self.datenumbers = [dateutil.parser.parse(s) for s in self.dates]
    self.units = 'Percent'
    self.title = 'Percentage Change in '+self.title